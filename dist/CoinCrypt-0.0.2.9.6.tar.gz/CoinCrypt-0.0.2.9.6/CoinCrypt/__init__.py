from requests import Session
import CoinCrypt.Coincrypt

